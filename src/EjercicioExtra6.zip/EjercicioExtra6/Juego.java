package EjercicioExtra6;

public class Juego {
    public static void main(String[] args) {

        AhocadoService as = new AhocadoService();

        as.juego();

    }
}
